from django.apps import AppConfig


class QappConfig(AppConfig):
    name = 'qapp'
