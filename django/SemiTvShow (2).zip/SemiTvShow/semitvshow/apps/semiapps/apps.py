from django.apps import AppConfig


class SemiappsConfig(AppConfig):
    name = 'semiapps'
