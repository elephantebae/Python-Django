from django.apps import AppConfig


class DistimeConfig(AppConfig):
    name = 'distime'
