from django.apps import AppConfig


class LoveConfig(AppConfig):
    name = 'love'
