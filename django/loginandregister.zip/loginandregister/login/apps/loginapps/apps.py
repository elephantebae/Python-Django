from django.apps import AppConfig


class LoginappsConfig(AppConfig):
    name = 'loginapps'
