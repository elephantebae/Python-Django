from django.apps import AppConfig


class NumgenConfig(AppConfig):
    name = 'numgen'
